# MyDynamicButtons

This is a Java JSP + Servlet project with MySQL backend.

## Features
- User Interface: View all buttons
- Admin Panel: Add/Delete buttons
- Database: MySQL
- Maven Project: WAR build for Tomcat

## Deploy on Railway / Tomcat
1. Push this repo to GitHub
2. Setup MySQL on Railway / local
3. Update DBConnection.java with DB credentials
4. Build WAR and deploy
